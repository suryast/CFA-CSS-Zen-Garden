# CFA-CSS-Zen-Garden
First attempt on designing front end using CSS

The original brief is here http://www.csszengarden.com/. I was inspired the CSS design by Elliot Jay Stocks for the brief.
I took the main structure of his css file and expanded on that while learning css for the first time.
